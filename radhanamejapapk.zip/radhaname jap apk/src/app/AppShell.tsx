import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { hashFor, tabFromHash, type TabId } from "./routes";
import { useJap } from "../store/JapStore";
import { useI18n, type DictKey } from "../store/I18n";
import {
  BeadIcon,
  GameIcon,
  ChartIcon,
  ListIcon,
  MicNavIcon,
  FireIcon,
  HomeIcon,
  GearIcon,
} from "../components/NavIcons";
import { CounterScreen } from "./screens/CounterScreen";
import { GameScreen } from "./screens/GameScreen";
import { ProgressScreen } from "./screens/ProgressScreen";
import { MantraScreen } from "./screens/MantraScreen";
import { VoiceScreen } from "./screens/VoiceScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { Splash } from "./Splash";
import { LanguageScreen } from "./LanguageScreen";

type Phase = "splash" | "lang" | "main";

const TABS: { id: TabId; labelKey: DictKey; Icon: typeof BeadIcon }[] = [
  { id: "counter", labelKey: "tabHome", Icon: HomeIcon },
  { id: "progress", labelKey: "tabStats", Icon: ChartIcon },
  { id: "mantra", labelKey: "tabMantra", Icon: ListIcon },
  { id: "voice", labelKey: "tabVoice", Icon: MicNavIcon },
  { id: "game", labelKey: "tabGame", Icon: GameIcon },
  { id: "settings", labelKey: "tabSettings", Icon: GearIcon },
];

const TITLES: Record<TabId, DictKey> = {
  counter: "appTitle",
  game: "tabGame",
  progress: "tabStats",
  mantra: "tabMantra",
  voice: "tabVoice",
  settings: "tabSettings",
};

export function AppShell() {
  const { mantra, streak, todayCount } = useJap();
  const { t, isSet } = useI18n();
  const [tab, setTab] = useState<TabId>(() => tabFromHash(window.location.hash));
  const [phase, setPhase] = useState<Phase>("splash");

  // mirror the active tab to the URL hash (deep links + back button)
  useEffect(() => {
    if (window.location.hash !== hashFor(tab)) {
      history.replaceState(null, "", hashFor(tab));
    }
  }, [tab]);

  useEffect(() => {
    const onHash = () => setTab(tabFromHash(window.location.hash));
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  return (
    <div className="flex min-h-screen justify-center bg-gradient-to-b from-[#F6DCAE] via-[#F3CE93] to-[#EBB871]">
      {/* app column */}
      <div className="relative flex min-h-screen w-full max-w-[430px] flex-col overflow-hidden bg-white shadow-[0_0_90px_rgba(120,70,20,0.28)]">
        {phase !== "splash" && (
          <>
            {/* header */}
            <header className="relative z-20 shrink-0 bg-gradient-to-b from-cream to-[#FDF3E0] px-4 pb-3 pt-[calc(env(safe-area-inset-top)+14px)]">
              <div className="flex items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-2.5">
                  <span className="font-deva flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-flame-soft to-flame-deep text-lg font-semibold text-white shadow-[0_6px_16px_rgba(228,87,10,0.35)]">
                    ॐ
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[15px] font-bold leading-tight text-ink">{t(TITLES[tab])}</p>
                    <p className="font-deva truncate text-xs font-medium text-flame">{mantra}</p>
                  </div>
                </div>

                <div
                  className="flex h-9 shrink-0 items-center gap-1.5 rounded-full border border-flame/25 bg-flame/10 px-3.5 text-flame"
                  aria-label={`${streak} day streak`}
                >
                  <FireIcon className="h-4 w-4" />
                  <span className="text-sm font-bold">
                    {streak} {t("dayStreak").split(" ")[0]}
                  </span>
                </div>
              </div>
            </header>

            {/* screen */}
            <main className="relative z-10 flex-1 overflow-y-auto overscroll-contain bg-white">
              <div key={tab} className="reveal in-view min-h-full">
                {tab === "counter" && <CounterScreen />}
                {tab === "game" && <GameScreen />}
                {tab === "progress" && <ProgressScreen />}
                {tab === "mantra" && <MantraScreen />}
                {tab === "voice" && <VoiceScreen />}
                {tab === "settings" && (
                  <SettingsScreen onOpenLanguage={() => setPhase("lang")} />
                )}
              </div>
            </main>

            {/* bottom nav */}
            <nav className="relative z-20 grid shrink-0 grid-cols-6 border-t border-black/5 bg-white/95 px-1 pb-[env(safe-area-inset-bottom)] pt-1.5 backdrop-blur">
              {TABS.map(({ id, labelKey, Icon }) => {
                const activeTab = tab === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setTab(id)}
                    aria-current={activeTab ? "page" : undefined}
                    className="group relative flex flex-col items-center gap-1 py-2 outline-none"
                  >
                    <span
                      className={cn(
                        "relative flex h-8 w-11 items-center justify-center rounded-full transition-all duration-300",
                        activeTab
                          ? "bg-gradient-to-br from-flame-soft to-flame-deep text-white shadow-[0_8px_18px_rgba(228,87,10,0.4)]"
                          : "text-ink/45 group-hover:text-flame",
                      )}
                    >
                      <Icon className="h-5 w-5" />
                      {id === "game" && todayCount > 0 && !activeTab && (
                        <span className="absolute right-1.5 top-0.5 h-1.5 w-1.5 rounded-full bg-flame" />
                      )}
                    </span>
                    <span
                      className={cn(
                        "text-[9.5px] font-semibold transition-colors",
                        activeTab ? "text-flame" : "text-ink/45",
                      )}
                    >
                      {t(labelKey)}
                    </span>
                  </button>
                );
              })}
            </nav>

            {/* language page (first run or from settings) */}
            {phase === "lang" && <LanguageScreen onDone={() => setPhase("main")} />}
          </>
        )}

        {/* splash on every app start */}
        {phase === "splash" && (
          <Splash onDone={() => setPhase(isSet ? "main" : "lang")} />
        )}
      </div>
    </div>
  );
}
