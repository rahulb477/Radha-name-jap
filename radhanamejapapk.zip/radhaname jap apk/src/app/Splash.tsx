import { useEffect, useState } from "react";
import { useI18n } from "../store/I18n";
import { BRAND_LOGO_URL, IMAGES } from "../lib/assets";

const SPLASH_MS = 7000;

export function Splash({ onDone }: { onDone: () => void }) {
  const { t } = useI18n();
  const [progress, setProgress] = useState(6);
  const [logoSrc, setLogoSrc] = useState(BRAND_LOGO_URL);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setProgress(94));
    const done = window.setTimeout(onDone, SPLASH_MS);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(done);
    };
  }, [onDone]);

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#F3EDE3]">
      <div className="w-[min(320px,82%)] rounded-[30px] border border-white/80 bg-gradient-to-b from-[#F7EADA] to-[#F2E3CF] px-8 pb-12 pt-12 text-center shadow-[0_30px_70px_rgba(150,100,40,0.18)]">
        {/* brand logo — hosted official artwork, bundled copy as offline fallback */}
        <img
          src={logoSrc}
          alt="Naam Jap — राधे"
          onError={() => setLogoSrc(IMAGES.logo)}
          className="mx-auto h-44 w-44 rounded-[38px] object-cover shadow-[0_18px_44px_rgba(180,110,30,0.35)]"
        />

        <div className="mx-auto mt-9 h-px w-14 bg-[#B98D5F]" />

        <p className="mt-5 text-sm font-medium tracking-[0.3em] text-[#8A5A33]">{t("splashTag")}</p>

        <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-[#E4D6C2]">
          <div
            className="h-full rounded-full bg-flame transition-[width] ease-out"
            style={{ width: `${progress}%`, transitionDuration: `${SPLASH_MS - 600}ms` }}
          />
        </div>
        <p className="mt-3 text-xs font-medium tracking-[0.25em] text-[#8A5A33]">{t("splashInit")}</p>
      </div>
    </div>
  );
}
