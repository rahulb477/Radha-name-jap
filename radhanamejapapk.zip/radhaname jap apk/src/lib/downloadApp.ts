/**
 * Packages the running application into ONE standalone app file
 * (a self-contained .html with all JS, CSS and artwork inlined)
 * and hands it to the browser as a download.
 *
 * The downloaded file can be:
 *  - opened directly (double-click) — the full app runs offline,
 *  - shared via WhatsApp / Drive / email,
 *  - hosted anywhere, or added to a phone home screen.
 */
import { APP_VERSION } from "./config";

export const APP_FILE_NAME = `NaamJap-Counter-v${APP_VERSION}.html`;

function triggerDownload(html: string) {
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = APP_FILE_NAME;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 5000);
}

export async function downloadAppFile(): Promise<boolean> {
  // Preferred: fetch the pristine built document (single-file release).
  try {
    const res = await fetch(window.location.href, { cache: "no-store" });
    if (!res.ok) throw new Error("bad status");
    const html = await res.text();
    if (!/id=["']root["']/.test(html)) throw new Error("not the app document");
    triggerDownload(html);
    return true;
  } catch {
    // Fallback: serialise the live document (still fully self-contained).
    try {
      triggerDownload("<!doctype html>\n" + document.documentElement.outerHTML);
      return true;
    } catch {
      return false;
    }
  }
}
